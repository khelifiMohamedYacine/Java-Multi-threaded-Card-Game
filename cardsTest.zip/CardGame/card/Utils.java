import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.StringJoiner;

public class Utils {

    /**
     * Returns a string of card values separated by spaces.
     *
     * @param cards the collection of cards
     * @return a space-separated string of card values
     */

    public static String getCardValues(Collection<Card> cards) {
        StringJoiner stringJoiner = new StringJoiner(" ");
        for (Card card : cards) {
            stringJoiner.add(String.valueOf(card.getValue()));
        }
        return stringJoiner.toString();
    }

    /**
     * Creates a new file or resets an existing file with the specified name.
     *
     * @param fileName the name of the file
     * @return the {@code Path} of the created or reset file
     * @throws RuntimeException if an I/O error occurs
     */

    public static Path createOrReset(String fileName) {
        Path path = Path.of(fileName);
        try {
            if (Files.exists(path)) {
                PrintWriter writer = new PrintWriter(path.toFile());
                writer.print("");
                writer.close();
            } else {
                Files.createFile(path);
            }
        } catch (IOException e) {
            throw new RuntimeException(e); // Wrap the exception as a runtime exception
        }
        return path;
    }
}
