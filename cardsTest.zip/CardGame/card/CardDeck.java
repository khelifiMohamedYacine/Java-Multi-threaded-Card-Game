import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * The {@code CardDeck} class represents a deck of cards that can be accessed and modified by players.
 * It provides methods for adding cards, locking the deck, and logging its state.
 */

public class CardDeck {

    /**
     * Represents a card deck identified by an {@code index}.
     * The deck holds cards in a {@code Queue<Card>} and ensures exclusive access via a write lock ({@code WriteLock}).
     */

    private final int index;
    private final Queue<Card> cards;
    private final ReentrantReadWriteLock.WriteLock lock;

    /**
     * Constructs a new {@code CardDeck} with the specified index.
     * Initializes the card queue and the lock.
     *
     * @param index the index of the deck
     */

    public CardDeck(int index) {
        this.index = index;
        cards = new LinkedBlockingQueue<>();
        lock = new ReentrantReadWriteLock().writeLock();
    }

    /**
     * Adds a card with the specified value to the deck.
     *
     * @param integer the value of the card to add
     */

    public void addCard(Integer integer) {

        cards.add(new Card(integer));
    }

    /**
     * Attempts to acquire the write lock for the deck.
     *
     * @return {@code true} if the lock was successfully acquired, {@code false} otherwise
     */

    public boolean tryLock() {

        return lock.tryLock();
    }

    /**
     * Releases the write lock for the deck.
     */

    public void unlock() {

        lock.unlock();
    }

    /**
     * Ensures that the current thread owns the write lock for the deck.
     * Throws an {@link IllegalStateException} if the deck is not locked by the current thread.
     */

    void checkOwned() {
        if (!lock.isHeldByCurrentThread()) {
            throw new IllegalStateException("Deck is not owned by this player");
        }
    }

    /**
     * Adds a card to the deck if the current thread holds the write lock.
     *
     * @param card the card to add to the deck
     */

    public void offer(Card card) {
        checkOwned();
        cards.offer(card);
    }

    /**
     * Removes and returns the card at the front of the deck if the current thread holds the write lock.
     *
     * @return the card at the front of the deck, or {@code null} if the deck is empty
     */

    public Card poll() {
        checkOwned();
        return cards.poll();
    }

    /**
     * Returns the index of the deck.
     *
     * @return the index of the deck
     */

    public int getIndex() {

        return index;
    }

    /**
     * Stops the deck, logging its current contents to a file.
     *
     * @throws RuntimeException if an error occurs while writing the log file
     */

    public void stop() {
        Path logFile = Utils.createOrReset("deck" + index + "_output.txt");
        String log = "deck" + index + " contents: " + Utils.getCardValues(cards);
        try {
            Files.write(logFile, log.getBytes(), StandardOpenOption.WRITE);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
