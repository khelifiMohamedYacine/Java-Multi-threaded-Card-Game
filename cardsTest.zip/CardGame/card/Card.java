/**
 * The {@code Card} class represents a card with a specific value and age.
 * The value of the card is immutable, while the age of the card can be incremented.
 * The age of the card represents how many times it has been "aged" or updated.
 */

public final class Card {

    /**
     * The card's value, which is immutable, The card's age, which can be incremented.
     */

    private final int value;
    private int age;

    /**
     * Constructs a new {@code Card} with the specified value. The age is initialized to 0.
     *
     * @param value the value of the card
     */

    public Card(int value) {
        this.value = value;
        this.age = 0;
    }

    /**
     * Returns the value of the card.
     *
     * @return the value of the card
     */

    public int getValue() {

        return value;
    }

    /**
     * Returns the current age of the card.
     * The age represents how many times the card has been aged or updated.
     *
     * @return the current age of the card
     */

    public int getAge() {
        return age;
    }

    /**
     * Increments the age of the card by 1.
     * This method can be called to simulate the passage of time or aging of the card.
     */

    public void incrementAge() {

        age++;
    }
}
