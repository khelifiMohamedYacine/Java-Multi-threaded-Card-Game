import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Represents a player in the card game. Each player has a hand of cards and can draw and discard cards
 * from their respective decks. The player can also win the game by having all cards of the same value.
 */

public class Player {

    /**
     * A comparator to sort cards by age in descending order.
     */

    public static final Comparator<Card> CARD_AGE_COMPARATOR = Collections.reverseOrder(Comparator.comparingInt(Card::getAge));
    private final int index;
    private final List<Card> cards;
    private final CardDeck drawDeck;
    private final CardDeck discardDeck;
    private final Consumer<Player> onPlayerWon;
    private Thread thread;
    private final Path logFile;

    /**
     * Constructs a new {@code Player} with the specified index, draw deck, discard deck,
     * and a callback to notify when the player wins.
     *
     * @param index the index of the player
     * @param drawDeck the deck from which the player draws cards
     * @param discardDeck the deck where the player discards cards
     * @param onPlayerWon a callback to handle the player winning
     */

    public Player(int index, CardDeck drawDeck, CardDeck discardDeck, Consumer<Player> onPlayerWon) {
        this.index = index;
        cards = new LinkedList<>();
        this.drawDeck = drawDeck;
        this.discardDeck = discardDeck;
        this.onPlayerWon = onPlayerWon;
        logFile = Utils.createOrReset("player" + index + "_output.txt");
    }

    /**
     * Adds a card with the specified value to the player's hand.
     *
     * @param cardValue the value of the card to add
     */

    public void addCard(int cardValue) {
        cards.add(new Card(cardValue));
    }

    /**
     * Starts the player's gameplay in a separate thread.
     */

    public void play() {
        thread = new Thread(this::doPlay, "Player " + index + " thread");
        thread.start();
    }

    /**
     * The main gameplay logic executed by the player thread.
     * Logs actions and checks for a win condition.
     */

    void doPlay() {
        log("player " + index + " initial hand " + Utils.getCardValues(cards));
        if (checkWin()) {
            thread.interrupt();
            return;
        }
        while (!thread.isInterrupted()) {
            playLoop();
        }
    }

    /**
     * Logs a message to both the console and the player's log file.
     *
     * @param content the message to log
     */

    private void log(String content) {
        System.out.println(content);
        String log = content + "\n";
        try {
            Files.write(logFile, log.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * The loop where the player draws a card from the draw deck, discards a card,
     * and checks if they have won the game.
     */

    private void playLoop() {
        if (!tryLockDrawAndDiscardDecks()) {
            return;
        }
        try {
            Card card = drawDeck.poll();
            //This case happen when drawDeck is empty, e.g. current player Thread is quicker then the previous one
            if (card == null) {
                //exit to retry the main loop, maybe there will a value in the next iteration
                return;
            }
            log("player " + index + " draws a " + card.getValue() + " from deck " + drawDeck.getIndex());
            addCard(card.getValue());
            Card oldestNotPreferred = getOldestNotPreferred();
            discardDeck.offer(oldestNotPreferred);
            cards.remove(oldestNotPreferred);
            updateCardAges();
            if (checkWin()) {
                thread.interrupt();
                return;
            }
            log("player " + index + " discards a " + oldestNotPreferred.getValue() + " to deck " + discardDeck.getIndex());
            log("player " + index + " current hand is " + Utils.getCardValues(cards));
        } finally {
            unlockDrawAndDiscardDecks();
        }
    }

    /**
     * Increments the age of all cards in the player's hand.
     */

    private void updateCardAges() {
        for (Card card : cards) {
            card.incrementAge();
        }
    }

    /**
     * Releases the locks on both the draw and discard decks.
     */

    private void unlockDrawAndDiscardDecks() {
        drawDeck.unlock();
        discardDeck.unlock();
    }

    /**
     * Tries to acquire the write lock on both the draw and discard decks.
     *
     * @return {@code true} if both decks were successfully locked, {@code false} otherwise
     */

    private boolean tryLockDrawAndDiscardDecks() {
        if (drawDeck.tryLock()) {
            if (discardDeck.tryLock()) {
                return true;
            } else {
                drawDeck.unlock();
            }
        }
        return false;
    }

    /**
     * Checks if the player has won the game, which happens when all cards have the same value.
     *
     * @return {@code true} if the player has won, {@code false} otherwise
     */

    private boolean checkWin() {
        int firstCardValue = cards.get(0).getValue();
        for (int i = 1; i < cards.size(); i++) {
            if (cards.get(i).getValue() != firstCardValue) {
                return false;
            }
        }
        log("player " + index + " wins");
        log("player " + index + " exits");
        log("player " + index + " final hand: " + Utils.getCardValues(cards));
        onPlayerWon.accept(this);
        return true;
    }

    /**
     * Returns the oldest card that is not preferred (does not have the player's index as its value).
     *
     * @return the oldest card that is not preferred
     * @throws IllegalStateException if all cards are preferred (i.e., the player should have won)
     */

    private Card getOldestNotPreferred() {
        cards.sort(CARD_AGE_COMPARATOR);
        for (Card card : cards) {
            if (card.getValue() != index) {
                return card;
            }
        }
        throw new IllegalStateException("Player should win here");
    }

    /**
     * Stops the player and logs that the winner has informed them of their victory.
     *
     * @param winner the player who won the game
     */

    public void stop(Player winner) {
        log("player " + winner.index + " has Informed player " + index + " that player " + winner.index + " has won");
        log("player " + index + " exits");
        log("player " + index + " hand: " + Utils.getCardValues(cards));
        thread.interrupt();
    }
}
