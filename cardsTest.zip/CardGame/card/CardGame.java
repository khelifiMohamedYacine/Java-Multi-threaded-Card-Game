import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The {@code CardGame} class represents the core logic of a card game with multiple players.
 * It handles game preparation, gameplay, and player actions.
 */

public class CardGame {

    /**
     * A map to store card decks by their index, And A list of players participating in the game.
     */

    private static final Map<Integer, CardDeck> DECKS = new HashMap<>();
    private static final List<Player> PLAYERS = new ArrayList<>();

    /**
     * Main method to prepare and launch the game.
     *
     * @param args command-line arguments (not used)
     * @throws Exception if an error occurs during game setup or execution
     */

    public static void main(String[] args) throws Exception {
        prepareGame();
        launchGame();
    }

    /**
     * Launches the game by making each player take their turn.
     */

    private static void launchGame() {
        for (Player player : PLAYERS) {
            player.play();
        }
    }

    /**
     * Called when a player wins the game.
     * Notifies other players to stop and stops all card decks.
     *
     * @param winner the player who won the game
     */

    private static void onPlayerWon(Player winner) {
        for (Player player : PLAYERS) {
            if (!player.equals(winner)) {
                player.stop(winner);
            }
        }
        for (CardDeck cardDeck : DECKS.values()) {
            cardDeck.stop();
        }
    }

    /**
     * Prepares the game by loading the card deck and initializing players.
     *
     * @throws IOException if an error occurs while reading the input or deck file
     */

    private static void prepareGame() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int playersNumber = getPlayersNumber(reader);
        List<Integer> pack = getPack(reader, playersNumber);
        reader.close();
        // Create players and assign them decks
        for (int i = 1; i <= playersNumber; i++) {
            CardDeck drawDeck = getOrCreateDeck(i, playersNumber);
            CardDeck discardDeck = getOrCreateDeck(i + 1, playersNumber);
            PLAYERS.add(new Player(i, drawDeck, discardDeck, CardGame::onPlayerWon));
        }
        // Distribute cards to players
        int packIndex = 0;
        int index = 0;
        while (index < 4) {
            for (Player player : PLAYERS) {
                player.addCard(pack.get(packIndex++));
            }
            index++;
        }
        while (index < 8) {
            for (CardDeck cardDeck : DECKS.values()) {
                cardDeck.addCard(pack.get(packIndex++));
            }
            index++;
        }
    }

    /**
     * Retrieves or creates a card deck for a player.
     *
     * @param index the index of the deck
     * @param playersNumber the total number of players
     * @return the card deck for the player
     */

    private static CardDeck getOrCreateDeck(int index, int playersNumber) {
        if (index > playersNumber) {
            return DECKS.get(1);
        }
        return DECKS.computeIfAbsent(index, k -> new CardDeck(index));
    }

    /**
     * Loads a pack of cards from a specified file.
     *
     * @param reader the reader to get input from
     * @param playersNumber the number of players in the game
     * @return a list of card values
     * @throws IOException if there is an error reading the file
     */

    private static List<Integer> getPack(BufferedReader reader, int playersNumber) throws IOException {
        boolean valid = false;
        List<Integer> pack = new ArrayList<>();
        do {
            System.out.println("Please enter location of pack to load:");
            String locationStr = reader.readLine();
            try {
                List<String> strings = Files.readAllLines(Path.of(locationStr));
                if (strings.size() == 8 * playersNumber) {
                    valid = true;
                    pack.clear();
                    for (String string : strings) {
                        try {
                            pack.add(Integer.parseInt(string));
                        } catch (NumberFormatException e) {
                            System.err.println("The file contains an invalid number: " + string);
                            valid = false;
                            break;
                        }
                    }
                } else {
                    System.err.println("Invalid file: The file must contain " + (8 * playersNumber) + " lines.");
                }
            } catch (IOException e) {
                System.err.println("Error reading the file at location: " + locationStr);
            }
        } while (!valid);
        return pack;
    }

    /**
     * Prompts the user to enter the number of players.
     *
     * @param reader the reader to get input from
     * @return the number of players
     * @throws IOException if an error occurs while reading input
     */

    private static int getPlayersNumber(BufferedReader reader) throws IOException {
        int numberOfPlayers = 1;
        boolean validInput = false;
        while (!validInput) {
            try {
                System.out.println("Please enter the number of players:");
                String numberStr = reader.readLine();
                numberOfPlayers = Integer.parseInt(numberStr);
                if (numberOfPlayers > 0) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. The number must be greater than 0.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }
        return numberOfPlayers;
    }
}