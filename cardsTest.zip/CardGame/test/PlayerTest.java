import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {

    @BeforeEach
    void setUp() {
        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);

        new Player(1, drawDeck, discardDeck, (winner) -> {
        });
        try {
            Files.createTempFile("player_log", ".txt");
        } catch (IOException e) {
            e.printStackTrace();
            fail("Could not create log file for testing.");
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    void addCard() throws Exception {
        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);
        Player player = new Player(1, drawDeck, discardDeck, (winner) -> {
        });
        player.addCard(3);
        Object cards = ReflexionUtils.getValue(player, "cards");
        assertEquals(LinkedList.class, cards.getClass());
        List<Card> cardList = (List<Card>) cards;
        assertEquals(1, cardList.size());
        assertEquals(3, cardList.get(0).getValue());
    }

    @Test
    void playTest() throws Exception {
        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);
        Player player = new Player(1, drawDeck, discardDeck, (winner) -> {
        });
        for (int i = 0; i < 4; i++) {
            drawDeck.addCard(new Random().nextInt(10));
            discardDeck.addCard(new Random().nextInt(10));
            player.addCard(new Random().nextInt(10));
        }
        assertNull(ReflexionUtils.getValue(player, "thread"));
        player.play();
        assertNotNull(ReflexionUtils.getValue(player, "thread"));
    }

    @Test
    void playCheckWinTest() throws Exception {
        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);
        AtomicBoolean playerWon = new AtomicBoolean(false);
        Consumer<Player> playerConsumer = (winner) -> playerWon.set(true);
        Player player = new Player(1, drawDeck, discardDeck, playerConsumer);
        for (int i = 0; i < 4; i++) {
            player.addCard(1);
        }
        assertFalse(playerWon.get());
        player.play();
        Thread.sleep(500);
        assertTrue(playerWon.get());
    }

    @Test
    void playLoopInterruptedTest() throws Exception {
        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);
        Player player = new Player(1, drawDeck, discardDeck, (winner) -> {
        });
        for (int i = 0; i < 4; i++) {
            drawDeck.addCard(new Random().nextInt(10));
            discardDeck.addCard(new Random().nextInt(10));
            player.addCard(new Random().nextInt(10));
        }
        player.play();
        Thread thread = ReflexionUtils.getValue(player, "thread");
        Thread.sleep(500);
        boolean playLoop = false;
        for (StackTraceElement stackTraceElement : thread.getStackTrace()) {
            if (stackTraceElement.getMethodName().equals("doPlay")) {
                playLoop = true;
                break;
            }
        }
        assertTrue(playLoop);
        thread.interrupt();
        Thread.sleep(500);
        assertEquals(0, thread.getStackTrace().length);
    }

    @Test
    void playLoopTest() throws Exception {
        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);
        Player player = new Player(1, drawDeck, discardDeck, (winner) -> {
        });
        List.of(1, 2, 3, 4).forEach(drawDeck::addCard);
        List.of(1, 2, 3, 4).forEach(discardDeck::addCard);
        List.of(1, 2, 3, 4).forEach(player::addCard);
        player.play();
        Thread.sleep(500);
        Queue<Card> drawDeckCards = ReflexionUtils.getValue(drawDeck, "cards");
        Queue<Card> discardDeckCards = ReflexionUtils.getValue(discardDeck, "cards");
        List<Card> playerCards = ReflexionUtils.getValue(player, "cards");
        assertEquals(0, drawDeckCards.size());
        assertEquals(8, discardDeckCards.size());
        assertEquals(4, playerCards.size());
    }

    @Test
    void playerWaitUntilDrawDeckUnlocked() throws Exception {
        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);
        Player player = new Player(1, drawDeck, discardDeck, (winner) -> {
        });
        List.of(1, 1, 1, 1).forEach(drawDeck::addCard);
        List.of(1, 2, 3, 4).forEach(discardDeck::addCard);
        List.of(1, 2, 3, 4).forEach(player::addCard);
        drawDeck.tryLock();
        player.play();
        Thread.sleep(500);
        List<Card> playerCards = ReflexionUtils.getValue(player, "cards");
        assertEquals(1, playerCards.get(0).getValue());
        assertEquals(0, playerCards.get(0).getAge());
        assertEquals(2, playerCards.get(1).getValue());
        assertEquals(0, playerCards.get(1).getAge());
        assertEquals(3, playerCards.get(2).getValue());
        assertEquals(0, playerCards.get(2).getAge());
        assertEquals(4, playerCards.get(3).getValue());
        assertEquals(0, playerCards.get(3).getAge());
    }

    @Test
    void stop() {
        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);
        new Player(1, drawDeck, discardDeck, (winner) -> {
        });
        drawDeck.addCard(5);
        drawDeck.addCard(10);
        drawDeck.addCard(2);
        drawDeck.stop();
        Path logFile = Path.of("deck1_output.txt");
        assertTrue(Files.exists(logFile), "The log file should exist.");
    }
}