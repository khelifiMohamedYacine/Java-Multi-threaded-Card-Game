import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CardDeckTest {
    private CardDeck deck;
    private Card card;

    @BeforeEach
    void setUp() {
        deck = new CardDeck(1);
        card = new Card(5);
    }

    @Test
    void getIndexTest() {
        assertEquals(1, deck.getIndex(), "Deck index should be 1");
    }

    @Test()
    void addCardWithoutLockTest() {
        deck.addCard(1);
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> deck.poll());
        assertEquals("Deck is not owned by this player", exception.getMessage());
    }

    @Test
    void addCardTest() {
        deck.addCard(1);
        deck.tryLock();
        assertNotNull(deck.poll(), "Card should be added and available for polling");
    }

    @Test
    void tryLockTest() {

        assertTrue(deck.tryLock(), "Deck should be lockable");
    }

    @Test
    void unlockTest() {
        deck.tryLock();
        deck.unlock();
        assertTrue(deck.tryLock(), "Deck should be lockable again after unlock");
    }

    @Test
    void offerTest() {
        deck.addCard(5);
        deck.tryLock();
        deck.offer(card);
        assertNotNull(deck.poll(), "Card should be added and available for polling");
    }

    @Test
    void offerWithoutLockTest() {
        deck.addCard(5);
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> deck.checkOwned());
        assertEquals("Deck is not owned by this player", exception.getMessage());
    }


    @Test
    void pollTest() {
        deck.addCard(5);
        deck.tryLock();
        Card polledCard = deck.poll();
        assertNotNull(polledCard, "Card should be polled from the deck");
        assertEquals(5, polledCard.getValue(), "Polled card should have value 5");
    }

    @Test
    void pollWithoutLockTest() {
        deck.addCard(5);
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> deck.poll());
        assertEquals("Deck is not owned by this player", exception.getMessage());
    }

    @Test
    void stopTest() throws IOException {
        Path tempLogFile = Files.createTempFile("deck1_output", ".txt");
        deck.stop();
        String logContents = Files.readString(tempLogFile);
        assertFalse(logContents.contains("deck1 contents:"));
        Files.delete(tempLogFile);
    }

    @Test
    void nonstopTest() throws IOException {
        Path tempLogFile = Files.createTempFile("deck1_output", ".txt");
        String logContents = Files.readString(tempLogFile);
        assertFalse(logContents.contains("deck1 contents:"));
        Files.delete(tempLogFile);
        assertThrows(IOException.class, () -> {
            Files.readString(tempLogFile);
        });
    }

    @Test
    void checkOwnedTest() {
        InvocationTargetException invocationTargetException = assertThrows(InvocationTargetException.class, () -> ReflexionUtils.invoke(deck, "checkOwned"));
        Throwable cause = invocationTargetException.getCause();
        assertEquals(IllegalStateException.class, cause.getClass());
        assertEquals("Deck is not owned by this player", cause.getMessage());
        deck.tryLock();
        assertDoesNotThrow(() -> ReflexionUtils.invoke(deck, "checkOwned"));
        deck.unlock();
        assertThrows(InvocationTargetException.class, () -> ReflexionUtils.invoke(deck, "checkOwned"));
    }

    @Test
    void playerDeckContentTest() throws IOException {

        CardDeck drawDeck = new CardDeck(1);
        CardDeck discardDeck = new CardDeck(2);

        new Player(1, drawDeck, discardDeck, (winner) -> {
        });

        deck.addCard(5);
        deck.addCard(10);
        deck.addCard(2);

        deck.stop();

        Path logFile = Path.of("deck1_output.txt");
        assertTrue(Files.exists(logFile), "The log file should exist.");

        List<String> lines = Files.readAllLines(logFile);
        String logContent = String.join("\n", lines);

        String expectedContent = "deck1 contents: 5 10 2";
        assertEquals(expectedContent, logContent, "The log file content should match the expected deck contents.");

        Files.delete(logFile);
    }
}








