import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class CardTest {
    private Card card;

    @BeforeEach
    void setUp() {

        card = new Card(10); // Create a card with a value of 10
    }

    @Test
    void getValue() {

        assertEquals(10, card.getValue(), "Card value should be 10");
    }

    @Test
    void getAge() {

        assertEquals(0, card.getAge(), "Initial age of the card should be 0");
    }

    @Test
    void incrementAge() {
        card.incrementAge();
        assertEquals(1, card.getAge(), "Card age should be incremented by 1");
    }
}