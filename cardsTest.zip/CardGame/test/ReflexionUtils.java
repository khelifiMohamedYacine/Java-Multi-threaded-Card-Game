import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflexionUtils {

    @SuppressWarnings("unchecked")
    public static <T> T invoke(Object object, String methodName) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Method method = object.getClass().getDeclaredMethod(methodName);
        method.setAccessible(true);
        return (T) method.invoke(object);
    }

    @SuppressWarnings("unchecked")
    public static <T> T getValue (Object object, String filedName) throws NoSuchFieldException, IllegalAccessException {
        Field declaredField = object.getClass().getDeclaredField(filedName);
        declaredField.setAccessible(true);
        return (T) declaredField.get(object);
    }
}
