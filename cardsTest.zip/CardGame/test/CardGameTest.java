
import org.junit.jupiter.api.Test;

import java.io.*;
import java.nio.file.*;



import static org.junit.jupiter.api.Assertions.*;

public class CardGameTest {

    @Test
    public void PlayerCountMismatchTest() throws Exception {

        Path packFile = Path.of("8.txt");

        assertTrue(Files.exists(packFile), "The 8.txt file should exist.");

        String simulatedInput = "4\n" + packFile + "\n" + Path.of("2_win.txt") + "\n";
        InputStream inputStream = new ByteArrayInputStream(simulatedInput.getBytes());
        System.setIn(inputStream);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setErr(new PrintStream(outputStream));


        CardGame.main(new String[]{});

        Thread.sleep(100);

        String output = outputStream.toString();

        System.out.println("Captured Output: \n" + output);

        String expectedErrorMessage = "Invalid file";
        assertTrue(output.contains(expectedErrorMessage),
                "Expected error message to contain '" + expectedErrorMessage + "'. Actual output: " + output);
    }

}
