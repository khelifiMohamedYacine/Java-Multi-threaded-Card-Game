import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class UtilsTest {

    @Test
    public void getCardValues() {
        List<Card> cards = List.of(new Card(1), new Card(2), new Card(3));
        String result = Utils.getCardValues(cards);
        assertEquals("1 2 3", result, "Card values should be returned as a space-separated string");
    }


    @Test
    public void createOrReset() throws IOException {
        Path tempFile = Files.createTempFile("testFile", ".txt");

        try {
            assertTrue(Files.exists(tempFile), "File should exist before reset");
            Path result = Utils.createOrReset(tempFile.toString());
            assertEquals(tempFile, result, "The returned path should be the same as the input path");
            String content = Files.readString(tempFile);
            assertEquals("", content, "File should be empty after reset");

        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

}